clc;
clear;
%Link offsets (d) [mm]
d1 = 114.3; d2 = 102.616; d3 = 77.216; d5 = 127; d7 = 50.8; d9 = -128; d10 = -76.2; d11=-51.8; d12=-153.42; d13=77.19; d14=-133.5;

% Link offsets in x direction (a) [mm]
a4 = 51.8; a6 = 101.6; a8 = -101.6; a13 = 102.55; a15 = 66.3;

%D-H table
%Format :Link([theta, d, a, alpha, R/P])
%R/P: R - Revolute(0) ; P - Prismatic(1)

%link1
L(1) = Link([ 0, d1, 0, -pi/2, 0]);
%link2
L(2) = Link([ 0, d2, 0, pi/2, 0]);
%dummy1
L(3) = Link([ 0, d3, 0, 0, 0]);
%link3
L(4) = Link([ pi/2, 0, a4, 0, 0]);
%dummy2
L(5) = Link([ -pi/2, d5, 0, 0, 0]);
%dummy3
L(6) = Link([ 0, 0, a6, -pi/2, 0]);
% %link4
L(7) = Link([ 0, d7, 0, -pi/2, 0]);
%dummy4
L(8) = Link([ 0, 0, a8, 0, 0]);
%dummy5
L(9) = Link([ 0, d9, 0, 0, 0]);
%link5
L(10) = Link([ pi/2, d10, 0, -pi/2, 0]);
% %dummy6
L(11) = Link([ 0, d11, 0, 0, 0]);
%link6
L(12) = Link([ 0, d12, 0, pi/2, 0]);
%dummy7
L(13) = Link([ 0, d13, a13, pi, 0]);
%end effector links
%link7
L(14) = Link([ 0, d14, 0, 0, 0]);
% %dummy8
L(15) = Link([ pi/2, 0, a15, pi/2, 0]);
robot = SerialLink (L);
robot.name = 'wheelchair-arm';
q1 = 0;
q2 = 0;
q3 = 0;
q4 = pi/2;
q5 = -pi/2;
q6 = 0;
q7 = 0;
q8 = 0;
q9 = 0;
q10 = pi/2;
q11 = 0;
q12 = 0;
q13 = 0;
q14 = 0;
q15 = pi/2;
% %plotting robot using teach() method
% robot.teach

%visualising robots workspace
for q1=-pi:0.314:pi/2
    for q2 = -pi/2:0.314:pi/2
        for q4 = -pi:0.314:pi
            for q7 = -pi/2:0.314:pi/2
                for q10 = -pi:0.314:pi
                    for q12 = -pi:0.314:pi
                        for q14 = -pi:0.314:pi
                            robot.plot ([q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q14,q15])
                        end
                    end
                end
            end
        end

    end
end
