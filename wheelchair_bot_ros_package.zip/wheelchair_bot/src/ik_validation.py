#!/usr/bin/env python3
import rospy

from std_msgs.msg import Float64

import sys, select, termios, tty
def manipulator_control():
    rospy.init_node('manipulator_control') 
    lmotor_1 = rospy.Publisher('/wheelchair_bot/link1_controller/command', Float64, queue_size=10)
    lmotor_2 = rospy.Publisher('/wheelchair_bot/link2_controller/command', Float64, queue_size=10)
    lmotor_3 = rospy.Publisher('/wheelchair_bot/link3_controller/command', Float64, queue_size=10)
    lmotor_4 = rospy.Publisher('/wheelchair_bot/link4_controller/command', Float64, queue_size=10)
    lmotor_5 = rospy.Publisher('/wheelchair_bot/link5_controller/command', Float64, queue_size=10)
    lmotor_6 = rospy.Publisher('/wheelchair_bot/link6_controller/command', Float64, queue_size=10)
    lmotor_7 = rospy.Publisher('/wheelchair_bot/gripper_base_controller/command', Float64, queue_size=10)
    gmotor_1 = rospy.Publisher('/wheelchair_bot/left_claw_controller/command', Float64, queue_size=10)
    gmotor_2 = rospy.Publisher('/wheelchair_bot/right_claw_controller/command', Float64, queue_size=10)
    rate = rospy.Rate(1) 
    rospy.loginfo("Data is being sent")  
    while not rospy.is_shutdown():
        twist = Float64()

        #Initial pose
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
	
	#2
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 1.763 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 1.763* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #3
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 1.923 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0.160 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 4.123* 0.01744
        lmotor_6.publish(twist)
        twist.data = -2.360* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #4
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 1.19 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.063 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -0.484 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 6.881* 0.01744
        lmotor_6.publish(twist)
        twist.data = -5.144* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #5
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -0.007 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.178 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -1.641 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 9.656* 0.01744
        lmotor_6.publish(twist)
        twist.data = -7.842* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        # #6
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -1.451 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.311 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -3.173 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 12.185* 0.01744
        lmotor_6.publish(twist)
        twist.data = -10.148* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #7
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -3.037 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.427 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -5.017 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 14.292* 0.01744
        lmotor_6.publish(twist)
        twist.data = -11.869* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #8
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -4.704 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.502 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -7.151 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 15.855* 0.01744
        lmotor_6.publish(twist)
        twist.data = -12.868* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #9
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -6.405 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.515 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -9.564 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 16.801* 0.01744
        lmotor_6.publish(twist)
        twist.data = -13.045* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
        #10
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -8.088 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.457 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -12.238 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 17.094* 0.01744
        lmotor_6.publish(twist)
        twist.data = -12.338* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        rate.sleep()
        
	#11
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -9.694 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.331 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -15.126 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 16.746 * 0.01744
        lmotor_6.publish(twist)
        twist.data = -10.74* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()

	#12
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -11.150 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0.155 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -18.117 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 15.807* 0.01744
        lmotor_6.publish(twist)
        twist.data = -8.323* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()


	#13
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -12.372 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.030 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -21 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 14.361* 0.01744
        lmotor_6.publish(twist)
        twist.data = -5.271* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()

	#14
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -13.260 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.173 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -23.406 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 12.503* 0.01744
        lmotor_6.publish(twist)
        twist.data = -1.923* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()



	#15
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -13.709 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.234 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -24.788 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 10.311* 0.01744
        lmotor_6.publish(twist)
        twist.data = 1.205* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()


	#16
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -13.617 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.223 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -24.454* 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 7.827* 0.01744
        lmotor_6.publish(twist)
        twist.data = 3.445* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()


	#17
        twist.data = 0* 0.01744
        lmotor_1.publish(twist)
        twist.data = -12.903 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.215 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -21.624  * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 5.072* 0.01744
        lmotor_6.publish(twist)
        twist.data = 4.007* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()


	#18
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -11.567 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.310 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -15.316 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 2.059* 0.01744
        lmotor_6.publish(twist)
        twist.data = 1.845* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()


	#19
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -9.892 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.465 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -2.688 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = -1.332* 0.01744
        lmotor_6.publish(twist)
        twist.data = -5.933* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()


	#20
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = -5.463 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -1.026 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -6.629 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data =-1.675 * 0.01744
        lmotor_6.publish(twist)
        twist.data = 2.217* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()

	#21
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0.024 * 0.01744
        lmotor_2.publish(twist)
        twist.data = -0.583 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -24.153 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 2.551* 0.01744
        lmotor_6.publish(twist)
        twist.data = 21.416* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()
        rate.sleep()
        
if __name__ == '__main__':
    try:
        manipulator_control()
    except rospy.ROSInterruptException: 
        pass
