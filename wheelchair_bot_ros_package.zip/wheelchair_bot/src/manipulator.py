#!/usr/bin/env python3
import rospy

from std_msgs.msg import Float64

import sys, select, termios, tty
def manipulator_control():
    rospy.init_node('manipulator_control') 
    lmotor_1 = rospy.Publisher('/wheelchair_bot/link1_controller/command', Float64, queue_size=10)
    lmotor_2 = rospy.Publisher('/wheelchair_bot/link2_controller/command', Float64, queue_size=10)
    lmotor_3 = rospy.Publisher('/wheelchair_bot/link3_controller/command', Float64, queue_size=10)
    lmotor_4 = rospy.Publisher('/wheelchair_bot/link4_controller/command', Float64, queue_size=10)
    lmotor_5 = rospy.Publisher('/wheelchair_bot/link5_controller/command', Float64, queue_size=10)
    lmotor_6 = rospy.Publisher('/wheelchair_bot/link6_controller/command', Float64, queue_size=10)
    lmotor_7 = rospy.Publisher('/wheelchair_bot/gripper_base_controller/command', Float64, queue_size=10)
    gmotor_1 = rospy.Publisher('/wheelchair_bot/left_claw_controller/command', Float64, queue_size=10)
    gmotor_2 = rospy.Publisher('/wheelchair_bot/right_claw_controller/command', Float64, queue_size=10)
    rate = rospy.Rate(1) 
    rospy.loginfo("Data is being sent")  
    while not rospy.is_shutdown():
        twist = Float64()

        #Initial pose
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()

        #position reaching pose
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 90 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -90 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()

        #grasping pose
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 90 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = -90 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = -5* 0.01744
        gmotor_1.publish(twist)
        twist.data = 5* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()

        #return pose
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_4.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = -5* 0.01744
        gmotor_1.publish(twist)
        twist.data = 5* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()
        
        #final pose
        twist.data = 90 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_4.publish(twist)
        twist.data = -90 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = -5* 0.01744
        gmotor_1.publish(twist)
        twist.data = 5* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()
       #return pose
        twist.data = 90 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_4.publish(twist)
        twist.data = -90 * 0.01744
        lmotor_5.publish(twist)
        twist.data = 0* 0.01744
        lmotor_6.publish(twist)
        twist.data = 0* 0.01744
        lmotor_7.publish(twist)
        twist.data = 0* 0.01744
        gmotor_1.publish(twist)
        twist.data = 0* 0.01744
        gmotor_2.publish(twist)
        twist.data = 0* 0.01744
        rate.sleep()       
        rate.sleep()
        

if __name__ == '__main__':
    try:
        manipulator_control()
    except rospy.ROSInterruptException: 
        pass
