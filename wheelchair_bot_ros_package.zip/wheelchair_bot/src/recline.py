#!/usr/bin/env python3
import rospy

from std_msgs.msg import Float64

import sys, select, termios, tty
def manipulator_control():
    rospy.init_node('manipulator_control') 
    lmotor_1 = rospy.Publisher('/wheelchair_bot/backseat_controller/command', Float64, queue_size=10)
    lmotor_2 = rospy.Publisher('/wheelchair_bot/headrest_controller/command', Float64, queue_size=10)
    lmotor_3 = rospy.Publisher('/wheelchair_bot/legrest_controller/command', Float64, queue_size=10)

    rate = rospy.Rate(1) 
    rospy.loginfo("Data is being sent")  
    while not rospy.is_shutdown():
        twist = Float64()

        #Initial pose
        twist.data = 10 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 30 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 45 * 0.01744
        lmotor_3.publish(twist)     
        rate.sleep()
        
        #final pose
        twist.data = 0 * 0.01744
        lmotor_1.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_2.publish(twist)
        twist.data = 0 * 0.01744
        lmotor_3.publish(twist)     
        rate.sleep()

if __name__ == '__main__':
    try:
        manipulator_control()
    except rospy.ROSInterruptException: 
        pass
